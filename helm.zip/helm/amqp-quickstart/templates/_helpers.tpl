{{/*
Expand the name of the chart.
*/}}
{{- define "amqp-quickstart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this.
*/}}
{{- define "amqp-quickstart.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Chart label.
*/}}
{{- define "amqp-quickstart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels applied to every resource.
*/}}
{{- define "amqp-quickstart.labels" -}}
helm.sh/chart: {{ include "amqp-quickstart.chart" . }}
app.kubernetes.io/name: {{ include "amqp-quickstart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels for a given component (producer or processor).
Usage: include "amqp-quickstart.selectorLabels" (dict "ctx" . "component" "producer")
*/}}
{{- define "amqp-quickstart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "amqp-quickstart.name" .ctx }}
app.kubernetes.io/instance: {{ .ctx.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end -}}

{{/*
Component-specific fullname, e.g. "<release>-amqp-quickstart-producer".
Usage: include "amqp-quickstart.componentName" (dict "ctx" . "component" "producer")
*/}}
{{- define "amqp-quickstart.componentName" -}}
{{- printf "%s-%s" (include "amqp-quickstart.fullname" .ctx) .component | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Name of the shared AMQP ConfigMap.
*/}}
{{- define "amqp-quickstart.configMapName" -}}
{{- printf "%s-amqp" (include "amqp-quickstart.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
